# Documentation QA report — [feature]

## Scope and source coverage
- Original sources inspected: [paths, pages/sections]
- Handover, clarification register, content plan, and claim coverage: [paths]
- Drafts inspected: [paths]
- Uninspected or unreadable material: [none or details]

## Findings
| Status | Document / section | Issue | Source evidence | Recommended fix | Resolution |
| --- | --- | --- | --- | --- | --- |
| PASS / WARNING / FAIL | [path / heading] | [specific claim or omission] | [page/section or "not verified"] | [action] | [open/fixed/rechecked] |

## Checks
- Source fidelity and claim traceability: [PASS/WARNING/FAIL, reason]
- Claim coverage: [PASS/WARNING/FAIL; verify every handover claim, disposition, destination, and omissions against source and drafts]
- Revised source impact, if applicable: [PASS/WARNING/FAIL; source-to-source comparison and stale passage review]
- Assumptions, unknowns, and contradictions: [status, reason]
- Procedures, permissions, and states: [status, reason]
- Terminology, audience fit, clarity, and duplication: [status, reason]
- Editorial blueprint and Draft challenge: [PASS/WARNING/FAIL; reader jobs, separation, task choice, release-note focus]
- Structural checker: [PASS/WARNING/FAIL; command and limits]

## Open questions and publication readiness
[Q IDs and affected passages. Distinguish assignment-complete drafts from publication-ready docs.]

## Corrections made and recheck
[What changed, source basis, and recheck result. Do not claim PASS for unchecked work.]
